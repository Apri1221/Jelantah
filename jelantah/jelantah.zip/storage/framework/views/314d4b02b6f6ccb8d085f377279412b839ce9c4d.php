<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Laravel</title>

    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <!-- font -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:300,400,700">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">

    <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>


    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

    <!-- Styles -->
    <style>
    body {
        font-family: 'Raleway', sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        display: flex;
        font-size: 18px !important;
        min-height: 100vh;
        flex-direction: column;
    }

    .navbar-fixed nav {
        padding: env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);
    }

    .footer-fixed footer {
        padding: env(safe-area-inset-top) env(safe-area-inset-right) env(safe-area-inset-bottom) env(safe-area-inset-left);
    }

    main {
        flex: 1 0 auto;
    }

    .footer-fixed {
        position: fixed;
        bottom: 0;
        z-index: 1080;
        width: 100%;
    }

    footer ul.justify {
        text-align: center;
        display: table;
        overflow: hidden;
        margin: 0 auto;
    }

    footer ul.justify li {
        margin-left: auto;
        margin-right: auto;
        width: 82px;
    }

    .splash-image-container {
        width: 100%;
        max-width: 740px;
    }

    @media  only screen and (max-width: 992px) {
        .splash-image-container {
            margin-top: 0;
            padding-top: 0px;
            width: 100%;
            height: 100%;
            text-align: center;
            max-width: initial
        }
    }

    .splash-image-kbremote {
        height: 100%;
        -webkit-border-radius: 8px;
        -moz-border-radius: 8px;
        -ms-border-radius: 8px;
        -o-border-radius: 8px;
        border-radius: 8px
    }

    .splash-image {
        width: 100%;
        -webkit-border-radius: 8px;
        -moz-border-radius: 8px;
        -ms-border-radius: 8px;
        -o-border-radius: 8px;
        border-radius: 8px
    }

    @media  only screen and (max-width: 992px) {
        .splash-image {
            width: 100%;
            max-width: 740px;
            max-height: 100%;
            margin-bottom: -44px
        }

        .splash-image-kbremote {
            width: 100%;
            max-width: 740px;
            max-height: 100%;
            margin-bottom: -44px
        }
    }


    /* label focus color */
    .input-field input:focus+label {
        color: #5c6bc0 !important;
    }

    /* label underline focus color */
    .row .input-field input:focus {
        border-bottom: 1px solid #5c6bc0 !important;
        box-shadow: 0 1px 0 0 #5c6bc0 !important
    }

    .input-field .prefix.active {
        color: #ffb300 !important;
    }

    .sidenav li>a,
    .subheader {
        font-size: 20px !important
    }

    .sidenav li>a.active {
        background-color: #00bcd4 !important;
        color: #fff
    }

    h1,
    h2,
    h3,
    h4,
    h5 {
        padding: 20px 0;
    }
    </style>

    <script>
    $(document).ready(function() {
        $('.parallax').parallax();
        $('.sidenav').sidenav({
            edge: 'right', // <--- CHECK THIS OUT
        });
    });
    </script>
</head>

<body>

    <div class="footer-fixed" id="menu">
        <nav class="z-depth-0 indigo lighten-1">
            <div id="nav-mobile" class="nav-wrapper">
                <a href="#" data-target="navigasi" class="sidenav-trigger right"><i
                        class="material-icons right">menu</i>Menu</a>
                <ul class="justify hide-on-med-and-down"
                    style="position: absolute; left: 50%; transform: translate(-50%);">
                    <li class="tab col s2"><a href="sass.html"><i class="material-icons left">search</i>Link with
                            Left Icon</a></li>
                    <li class="tooltipped tab col s2" data-position="top" data-tooltip="Github">
                        <a href="https://github.com/Apri1221?tab=repositories"><i class="material-icons">code</i></a>
                    </li>
                    <li class="tooltipped tab col s2" data-position="top" data-tooltip="LinkedIn">
                        <a class="active" href="https://www.linkedin.com/in/apriyanto-tobing-95b4b612a/"><i
                                class="material-icons">account_circle</i></a></li>
                    <li class="tooltipped tab col s2" data-position="top" data-tooltip="Medium">
                        <a href="https://medium.com/@apriyantotobing8"><i class="material-icons">book</i></a></li>
                </ul>
            </div>
        </nav>

        <ul class="sidenav" id="navigasi">
            <li class="subheader center-align">Features</li>
            <li><a class="waves-effect active" href="#">Beranda</a></li>
            <div class="divider"></div>
            <li><a class="waves-effect" href="badges.html">Apri</a></li>
            <div class="divider"></div>
            <li><a class="waves-effect" href="collapsible.html">Kezia dan Dolin</a></li>
            <div class="divider"></div>
            <li><a class="waves-effect" href="mobile.html">Bersatu</a></li>
        </ul>
    </div>

    <div class="white no-pad-top">
        <div class="section amber darken-1 no-pad-bot z-depth-1 start-splash-section">
            <div class="container start-splash-container" style="margin-top:5em">
                <div class="row">
                    <div class="col s12 l6">
                        <div class="white-text start-splash-header-content">
                            <h4 class="white-text start-header-paragraph-text">
                                Create public kiosks, interactive digital signage and more with any Android&trade;
                                device. Display your web page(s) and prevent access to system settings &amp; other
                                applications.
                            </h4>
                            <a
                                href="https://play.google.com/store/apps/details?id=com.procoit.kioskbrowser&amp;utm_source=global_co&amp;utm_medium=prtnr&amp;utm_content=Mar2515&amp;utm_campaign=PartBadge&amp;pcampaignid=MKT-Other-global-all-co-prtnr-py-PartBadge-Mar2515-1"><img
                                    alt="Get it on Google Play"
                                    src="https://www.android-kiosk.com/wp-content/themes/androidkioskcom/images/google-play-badge.png"
                                    width="148"></a>
                            <!--<a class="waves-effect waves-light btn white text-primarycolor" style="margin-bottom:50px;margin-right: 10px;margin-top:0px;" href="http://sites.fastspring.com/androidkiosk/product/kioskbrowserpro"><i class="mdi mdi-credit-card left" ></i>Buy</a>-->
                            <a class="waves-effect waves-light btn white modal-trigger"
                                style="margin-bottom:50px;margin-right: 10px;margin-top:0px; color:black;"
                                href="#">Selengkapnya</a>
                        </div>
                        </p>
                    </div>
                    <div class="col s12 l6">
                        <div class="splash-image-container">
                            <img src="https://www.android-kiosk.com/wp-content/themes/androidkioskcom/images/splash5.png"
                                class="splash-image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="container" style="margin-bottom:5em">

        <div class="section white">
            <h2 class="header">Every heroes didnt wear a capes</h2>
            <p class="grey-text text-darken-3 lighten-3">Love the process.</p>
        </div>
        <div class="parallax-container">
            <div class="parallax"><img src="https://brandjaws.com/images/boy.png"></div>
        </div>

        <div class="section white">
            <h3 class="header">Tertarik menggunakan layanan kami?</h3>
        </div>

        <div class="row">
            <div class="col s12 l5">
                <div class="card amber lighten-5">
                    <div class="card-content">
                        <h5 class="center-align">Buat akun kamu</h5>
                        <form>
                            <div class="section">
                                <div class="input-field">
                                    <i class="material-icons prefix">people</i>
                                    <label for="username">Username</label>
                                    <input type="text" id="username" class="validate" required=""
                                        aria-required="true" />
                                </div>
                                <div class="input-field">
                                    <i class="material-icons prefix">vpn_key</i>
                                    <label for="password">Password</label>
                                    <input type="password" id="password" class="validate" required=""
                                        aria-required="true" />
                                </div>
                            </div>
                            <p>Izinkan kami memberikan informasi terbaru terkait produk jelantah kepada kamu melalui
                                email. Kami tidak akan spam</p>
                            <div class="section">
                                <div class="input-field">
                                    <i class="material-icons prefix">email</i>
                                    <label for="email">Email</label>
                                    <input type="email" id="email" class="validate" />
                                </div>
                            </div>
                            <div class="center-align">
                                <button class="btn waves-effect waves-light indigo lighten-1 btn-large" type="submit"
                                    name="action">Submit
                                    <i class="material-icons right">send</i>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col s12 l7">
                <div class="splash-image-container">
                    <img src="<?php echo e(asset('assets/image/undraw_Chef_cu0r.svg')); ?>" class="splash-image">
                </div>
            </div>
        </div>

        <!-- SnapWidget -->
        <div class="snapwidget-rpf" data-widget-id="775058"></div>
        <script>
        ! function(s, n, ap) {
            if (!s.getElementById(ap)) {
                var a = s.createElement("script");
                a.id = ap, a.src = "https://snapwidget.com/js/snapwidget-rpf.js", s.getElementsByTagName("head")[0]
                    .appendChild(a)
            }
        }(document, 0, "snaprpf");
        </script>
        </script>

    </div>

    <script>
    $(document).ready(function() {
        $('.tooltipped').tooltip({
            delay: 50
        });
    });
    </script>

</body>

</html><?php /**PATH C:\Users\Apriyanto JPL Tobing\Documents\MyRepo\Jelantah\jelantah\resources\views/welcome.blade.php ENDPATH**/ ?>